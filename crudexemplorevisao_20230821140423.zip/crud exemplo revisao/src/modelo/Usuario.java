/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
public class Usuario {
    
    String login;
    String senha;
    
    public String getsenha() {
        return senha;
    }
    public void setsenha(String senha) {
        this.senha = senha;
    }
    public String getlogin() {
        return login;
    }
    public void setlogin(String login) {
        this.login = login;

    }
   
}